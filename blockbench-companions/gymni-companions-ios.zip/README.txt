Unzip before adding assets to the iOS target. Ship only needed USDZ files and ios-clips.json.
Each USDZ has one skeletal animation bank. Trim the imported bank to the named start/end seconds; repeat only loop=true clips.
Stop competing procedural body/orbit motion. Honor Reduce Motion and pause offscreen.
Validated with OpenUSD on Windows; RealityKit import, clip trimming, materials and device performance remain untested.
