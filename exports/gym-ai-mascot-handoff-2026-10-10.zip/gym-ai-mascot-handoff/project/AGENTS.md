# Gym&AI mascot asset handoff

Read ../HANDOFF.md before working. This is an asset/iOS snapshot, not the full backend repository.

- Only Pip has a Blender model. Atlas and Flex have selected raster concepts; build them rather than claiming meshes already exist.
- Start from the rounded Pip source and the glossy V5 trio reference.
- Use .agents/skills/code-tips-skill/SKILL.md when writing code, and .agents/skills/swiftui-pro/SKILL.md for SwiftUI.
- Preserve Pip's Body, Orbit, and RightArm object names, separate parts, and source/export axis conventions unless coordinating an integration change.
- Preserve #0097B2, the iOS 17 deployment target, speech cancellation/mute behavior, Reduce Motion, and offscreen teardown.
- Save artist work in a separate .blend. Rebuilding build_pip.py overwrites generated Pip files and loses scene-only animation edits.
- Current animation is procedural RealityKit. Validate Blender animation export and native playback before replacing it; avoid two animation drivers modifying the same parts.
- Inspect native appearance, controls, transitions, and small thumbnail framing. Report device/runtime checks that cannot be performed.
- Return editable model/rig/Actions, USDZ and dependencies, transparent preview, motion preview, and an integration note.
