# Atlas — model not built yet

Atlas / Get stronger: fuzzy charcoal character with a sweeping #0097B2 band and sturdy friendly proportions.

Use ../../gym-ai-mascots-v5-glossy-pip.png as the selected trio reference. No .blend, USDZ, rig, or animation clips exist for this character in the source snapshot. Read the package HANDOFF.md for modeling, animation, and delivery requirements.
