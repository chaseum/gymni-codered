# Flex — model not built yet

Flex / Build muscle: thick open sculptural ribbon with a matte charcoal exterior and #0097B2 interior, face, and short feet.

Use ../../gym-ai-mascots-v5-glossy-pip.png as the selected trio reference. No .blend, USDZ, rig, or animation clips exist for this character in the source snapshot. Read the package HANDOFF.md for modeling, animation, and delivery requirements.
