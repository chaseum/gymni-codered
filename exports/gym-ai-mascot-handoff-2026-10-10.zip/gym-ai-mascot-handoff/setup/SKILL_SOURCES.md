# Included skill snapshots

These are local skill files used by the Gym&AI project, copied on October 10, 2026. They are instructions and references, not installed applications or MCP servers. No personal Codex settings, authentication, or credentials are included.

## code-tips-skill

Source: https://github.com/chaseum/code-tips-skill

Copied from the team's installed skill: SKILL.md, README.md, and references. The README attributes the principles to Robert C. Martin's Clean Code and describes the examples as original restatements. No separate LICENSE file was present in that local skill snapshot; preserve the source and attribution when sharing it further.

## swiftui-pro

Source: https://github.com/twostraws/SwiftUI-Agent-Skill

Author: Paul Hudson. Installed skill metadata version: 2.0.0. License: MIT. The upstream LICENSE is included in the skill directory. Only the active top-level SKILL.md and reference files are copied, avoiding the duplicate nested installation.

Use these project-local copies as the handoff's reproducible guidance. If you install upstream versions instead, record any changes in behavior. Preserve Gym&AI's existing iOS 17 target and installed-toolchain constraints even if a skill describes newer defaults.

Codex loads project skills from .agents/skills and user skills from ~/.agents/skills: https://learn.chatgpt.com/docs/build-skills

The optional Blender MCP example follows the community maintainer's setup: https://github.com/ahujasid/mcp-for-blender

No Blender MCP server or add-on source is bundled, installed, or tested by this handoff. Follow the linked maintainer instructions on the receiving computer if desired.
